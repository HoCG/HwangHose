--------------------------------------------------------
--  ������ ������ - �Ͽ���-12��-01-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table �ʰ���
--------------------------------------------------------

  CREATE TABLE "SYS"."�ʰ���" 
   (	"�ʰ����̸�" VARCHAR2(50 BYTE), 
	"��������" VARCHAR2(50 BYTE), 
	"��ġ" VARCHAR2(50 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index SYS_C007172
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS"."SYS_C007172" ON "SYS"."�ʰ���" ("�ʰ����̸�") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table �ʰ���
--------------------------------------------------------

  ALTER TABLE "SYS"."�ʰ���" ADD PRIMARY KEY ("�ʰ����̸�")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "SYS"."�ʰ���" MODIFY ("��ġ" NOT NULL ENABLE);
  ALTER TABLE "SYS"."�ʰ���" MODIFY ("��������" NOT NULL ENABLE);
