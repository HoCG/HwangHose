--------------------------------------------------------
--  ������ ������ - �Ͽ���-12��-01-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table �Խñ�
--------------------------------------------------------

  CREATE TABLE "SYS"."�Խñ�" 
   (	"�Խñ۹�ȣ" NUMBER(37,0), 
	"�ۼ���" VARCHAR2(50 BYTE), 
	"�Խ���" VARCHAR2(50 BYTE), 
	"�Խó���" VARCHAR2(100 BYTE)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index SYS_C007093
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS"."SYS_C007093" ON "SYS"."�Խñ�" ("�Խñ۹�ȣ") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table �Խñ�
--------------------------------------------------------

  ALTER TABLE "SYS"."�Խñ�" ADD PRIMARY KEY ("�Խñ۹�ȣ")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "SYS"."�Խñ�" MODIFY ("�Խó���" NOT NULL ENABLE);
  ALTER TABLE "SYS"."�Խñ�" MODIFY ("�Խ���" NOT NULL ENABLE);
  ALTER TABLE "SYS"."�Խñ�" MODIFY ("�ۼ���" NOT NULL ENABLE);
