--------------------------------------------------------
--  ������ ������ - �Ͽ���-12��-01-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table ��ȭ����
--------------------------------------------------------

  CREATE TABLE "SYS"."��ȭ����" 
   (	"��ȭü������" VARCHAR2(50 BYTE), 
	"���" NUMBER(37,0), 
	"�����ο�" NUMBER(37,0)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index SYS_C007136
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS"."SYS_C007136" ON "SYS"."��ȭ����" ("��ȭü������") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table ��ȭ����
--------------------------------------------------------

  ALTER TABLE "SYS"."��ȭ����" ADD PRIMARY KEY ("��ȭü������")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
