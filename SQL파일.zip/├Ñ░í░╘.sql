--------------------------------------------------------
--  ������ ������ - �Ͽ���-12��-01-2019   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table å����
--------------------------------------------------------

  CREATE TABLE "SYS"."å����" 
   (	"å��ȣ" NUMBER(37,0), 
	"å�̸�" VARCHAR2(50 BYTE), 
	"����" VARCHAR2(50 BYTE), 
	"����" NUMBER(37,0)
   ) PCTFREE 10 PCTUSED 40 INITRANS 1 MAXTRANS 255 NOCOMPRESS LOGGING
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  DDL for Index SYS_C007180
--------------------------------------------------------

  CREATE UNIQUE INDEX "SYS"."SYS_C007180" ON "SYS"."å����" ("å��ȣ") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM" ;
--------------------------------------------------------
--  Constraints for Table å����
--------------------------------------------------------

  ALTER TABLE "SYS"."å����" ADD PRIMARY KEY ("å��ȣ")
  USING INDEX PCTFREE 10 INITRANS 2 MAXTRANS 255 
  STORAGE(INITIAL 65536 NEXT 1048576 MINEXTENTS 1 MAXEXTENTS 2147483645
  PCTINCREASE 0 FREELISTS 1 FREELIST GROUPS 1 BUFFER_POOL DEFAULT FLASH_CACHE DEFAULT CELL_FLASH_CACHE DEFAULT)
  TABLESPACE "SYSTEM"  ENABLE;
  ALTER TABLE "SYS"."å����" MODIFY ("����" NOT NULL ENABLE);
  ALTER TABLE "SYS"."å����" MODIFY ("����" NOT NULL ENABLE);
  ALTER TABLE "SYS"."å����" MODIFY ("å�̸�" NOT NULL ENABLE);
